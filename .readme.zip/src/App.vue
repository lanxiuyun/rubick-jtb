<script setup lang="ts">
import { NConfigProvider } from "naive-ui";
</script>

<template>
  <n-config-provider>
    <router-view />
  </n-config-provider>
</template>

<style scoped></style>
