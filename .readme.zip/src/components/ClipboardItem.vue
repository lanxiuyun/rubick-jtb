<template>
  <div class="list-item">
    <div class="item-time">{{ timeLabel }}</div>

    <div class="item-content">
      <!-- 图片类型 -->
      <div v-if="record.type === 'image'" class="image-block">
        <n-image :src="imageUrl" height="120" width="120" object-fit="cover" />
        <div v-if="fileSize || imageDimensions" class="meta-info">
          <span v-if="fileSize">{{ fileSize }}</span>
          <span v-if="imageDimensions">{{ imageDimensions }}</span>
        </div>
      </div>

      <!-- 文本类型 -->
      <div v-else-if="record.type === 'text'" class="text-block">
        {{ displayText }}
      </div>

      <!-- 文件类型 -->
      <div v-else class="file-block">
        <div
          v-for="(file, idx) in displayedFiles"
          :key="`${file.path}-${idx}`"
          class="file-row"
        >
          <n-icon :color="file.color" size="16">
            <component :is="file.icon" />
          </n-icon>
          <span class="file-name">{{ file.name }}</span>
        </div>
        <div v-if="hasMoreFiles" class="show-more" @click.stop="toggleShowAll">
          {{ showAllFiles ? "收起" : `显示更多 ${remainingFilesCount} 条信息` }}
        </div>
      </div>
    </div>

    <div class="item-index">{{ index }}</div>
  </div>
</template>

<script setup lang="ts">
import type { ClipboardRecord, FileInfo } from "@/types/services";
import { formatFileSize, truncateText } from "@/utils/clipboard";
import {
  AppsOutline,
  DocumentAttachOutline,
  ImageOutline,
} from "@/utils/icons";
import { getRelativeTime } from "@/utils/time";
import { NIcon, NImage } from "naive-ui";
import type { Component } from "vue";
import { computed, ref, watch } from "vue";

interface FileItemInfo extends FileInfo {
  icon: Component;
  color: string;
}

const props = defineProps<{
  record: ClipboardRecord;
  index: number;
}>();

const timeLabel = computed(() => getRelativeTime(props.record.timestamp));

// ===== 文本类型相关 =====
const displayText = computed(() =>
  props.record.type === "text"
    ? truncateText(props.record.value as string, 150)
    : ""
);

// ===== 图片类型相关 =====
const imageDimensions = ref("");

const imageUrl = computed(() =>
  props.record.type === "image" ? `file:///${props.record.value}` : ""
);

const fileSize = computed(() => {
  if (props.record.type === "image" && "size" in props.record) {
    return formatFileSize((props.record as { size: number }).size);
  }
  return "";
});

const loadImageDimensions = () => {
  if (props.record.type !== "image") {
    imageDimensions.value = "";
    return;
  }

  const img = new Image();
  img.onload = () => {
    imageDimensions.value = `${img.width} x ${img.height}`;
  };
  img.onerror = (error) => {
    console.error("图片尺寸获取失败", error);
  };
  img.src = imageUrl.value;
};

watch(() => props.record, loadImageDimensions, { immediate: true, deep: true });

// ===== 文件类型相关 =====
const IMAGE_EXTENSIONS = new Set([
  "png",
  "jpg",
  "jpeg",
  "gif",
  "bmp",
  "svg",
  "webp",
]);

const showAllFiles = ref(false);

const getFileItemInfo = (file: FileInfo): FileItemInfo => {
  const ext = file.name.split(".").pop()?.toLowerCase() || "";
  const isImage = IMAGE_EXTENSIONS.has(ext);

  if (file.isDirectory) {
    return { ...file, icon: AppsOutline, color: "#3b82f6" };
  }

  if (isImage) {
    return { ...file, icon: ImageOutline, color: "#10b981" };
  }

  return { ...file, icon: DocumentAttachOutline, color: "#2563eb" };
};

const filesInfo = computed<FileItemInfo[]>(() => {
  if (props.record.type !== "files") return [];

  const files = props.record.value as FileInfo[];
  return files.map(getFileItemInfo);
});

const hasMoreFiles = computed(() => filesInfo.value.length > 5);

const remainingFilesCount = computed(() =>
  Math.max(0, filesInfo.value.length - 5)
);

const displayedFiles = computed(() => {
  if (showAllFiles.value) {
    return filesInfo.value;
  }
  return filesInfo.value.slice(0, 5);
});

const toggleShowAll = () => {
  showAllFiles.value = !showAllFiles.value;
};
</script>

<style scoped lang="scss">
.list-item {
  display: flex;
  padding: 12px;
  border-bottom: 1px solid #f0f0f0;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  border-radius: 4px;
  position: relative;

  &:hover {
    background-color: #f5f5f5;
    transform: translateX(4px);
    box-shadow: -4px 0 0 0 var(--n-color, #18a058),
      0 2px 8px rgba(0, 0, 0, 0.08);

    .item-time {
      color: var(--n-color, #18a058);
      font-weight: 500;
    }

    .item-index {
      color: var(--n-color, #18a058);
      font-weight: 600;
      transform: scale(1.1);
    }
  }
}

.item-time {
  width: 80px;
  font-size: 13px;
  padding-top: 4px;
  flex-shrink: 0;
  color: #666;
  transition: all 0.3s ease;
}

.item-content {
  flex: 1;
  padding-right: 16px;
  min-width: 0;
}

.item-index {
  width: 30px;
  text-align: right;
  color: #999;
  transition: all 0.3s ease;
}

.text-block {
  word-break: break-word;
}

.image-block {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.meta-info {
  font-size: 12px;
  color: #999;
  display: flex;
  gap: 12px;
}

.file-block {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.file-row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: #555;
}

.file-name {
  color: #333;
}

.show-more {
  font-size: 12px;
  color: var(--n-color, #18a058);
  cursor: pointer;
  padding: 6px 0;
  transition: all 0.3s ease;
  user-select: none;

  &:hover {
    color: var(--n-color-hover, #36ad6a);
    font-weight: 500;
  }
}
</style>
